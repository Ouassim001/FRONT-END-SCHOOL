const personen = [
	{
	   "voornaam": "Piet",
	   "achternaam": "Heijn",
	   "nationaliteit": "Nederlandse",
	   "leeftijd": 47,
	   "gewicht": 86
	},
	{
	   "voornaam": "Masud",
	   "achternaam": "Mohammed",
	   "nationaliteit": "Iraans",
	   "leeftijd": 37,
	   "gewicht": 79
	},
	{
	   "voornaam": "Marie",
	   "achternaam": "Visser",
	   "nationaliteit": "Belgische",
	   "leeftijd": 42,
	   "gewicht": 69
	},
	{
	   "voornaam": "Klaas",
	   "achternaam": "Wever",
	   "nationaliteit": "Nederlandse",
	   "leeftijd": 73,
	   "gewicht": 85
	},
	{
	   "voornaam": "Bjorn",
	   "achternaam": "Hakke",
	   "nationaliteit": "Zweeds",
	   "leeftijd": 18,
	  
    }]